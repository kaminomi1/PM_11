﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace WpfApp32
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string connectionString = "Server=DESKTOP-159LLU1\\KAMI0YASU;Database=СервисЦентрРемонта;Integrated Security=True;";


        public MainWindow()
        {
            InitializeComponent();
            LoadRequests();
        }
        // Загрузить заявки
        private void LoadRequests()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "SELECT * FROM Заявки ORDER BY Дата_создания DESC";
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgRequests.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки заявок:\n" + ex.Message);
            }
        }

        // Добавить новую заявку
        private void AddRequest_Click(object sender, RoutedEventArgs e)
        {
            string desc = tbDescription.Text.Trim();
            string client = tbClient.Text.Trim();
            string contact = tbContact.Text.Trim();
            string status = (cbStatus.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Новая";

            if (string.IsNullOrEmpty(desc) || string.IsNullOrEmpty(client))
            {
                MessageBox.Show("Заполните обязательные поля: Описание и Клиент");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string insertQuery = "INSERT INTO Заявки (Описание, Клиент, Стоимость, Статус, Дата_создания) " +
                                         "VALUES (@Описание_проблемы, @ID_Клиента, @Стоимость, @ID_Статуса, @Дата_создания)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Описание_проблемы", desc);
                        cmd.Parameters.AddWithValue("@ID_Клиента", client);
                        cmd.Parameters.AddWithValue("@Стоимость", contact);
                        cmd.Parameters.AddWithValue("@@ID_Статуса", status);
                        cmd.Parameters.AddWithValue("@Дата_создания", DateTime.Now);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Заявка успешно добавлена!");

                // Очистить форму
                tbDescription.Clear();
                tbClient.Clear();
                tbContact.Clear();
                cbStatus.SelectedIndex = 0;

                LoadRequests();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении заявки:\n" + ex.Message);
            }
        }

        // Обновить таблицу заявок
        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadRequests();
        }

        // Удалить выбранную заявку
        private void DeleteRequest_Click(object sender, RoutedEventArgs e)
        {
            if (dgRequests.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку для удаления.");
                return;
            }

            DataRowView row = dgRequests.SelectedItem as DataRowView;
            int id = Convert.ToInt32(row["ID_Заявки"]);

            MessageBoxResult result = MessageBox.Show($"Удалить заявку №{id}?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        string deleteQuery = "DELETE FROM Заявки WHERE ID_Заявки = @id";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", id);

                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Заявка удалена.");
                    LoadRequests();
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка удаления заявки:\n" + ex.Message);
                }
            }
        }

        // Редактировать выбранную заявку
        private void EditRequest_Click(object sender, RoutedEventArgs e)
        {
            if (dgRequests.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку для редактирования.");
                return;
            }

            DataRowView row = dgRequests.SelectedItem as DataRowView;
            int id = Convert.ToInt32(row["ID_Заявки"]);
            string currentDesc = row["Описание"].ToString();
            string currentClient = row["Клиент"].ToString();
            string currentContact = row["Контакт"].ToString();
            string currentStatus = row["Статус"].ToString();

            EditWindow editWindow = new EditWindow(id, currentDesc, currentClient, currentContact, currentStatus, connectionString);
            editWindow.ShowDialog();

            LoadRequests();
        }
    }
}
