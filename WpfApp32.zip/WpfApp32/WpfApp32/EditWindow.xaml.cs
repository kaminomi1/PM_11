﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace WpfApp32
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        private int requestId;
        private string connectionString;

        public EditWindow(int id, string desc, string client, string contact, string status, string connStr)
        {
            InitializeComponent();

            requestId = id;
            connectionString = connStr;

            tbDescription.Text = desc;
            tbClient.Text = client;
            tbContact.Text = contact;

            // Установить выбранный статус
            foreach (ComboBoxItem item in cbStatus.Items)
            {
                if (item.Content.ToString() == status)
                {
                    cbStatus.SelectedItem = item;
                    break;
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            string desc = tbDescription.Text.Trim();
            string client = tbClient.Text.Trim();
            string contact = tbContact.Text.Trim();
            string status = (cbStatus.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Новая";

            if (string.IsNullOrEmpty(desc) || string.IsNullOrEmpty(client))
            {
                MessageBox.Show("Описание и Клиент обязательны для заполнения.");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string updateQuery = "UPDATE Заявки SET Описание = @desc, Клиент = @client, Контакт = @contact, Статус = @status WHERE ID_Заявки = @id";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@desc", desc);
                        cmd.Parameters.AddWithValue("@client", client);
                        cmd.Parameters.AddWithValue("@contact", contact);
                        cmd.Parameters.AddWithValue("@status", status);
                        cmd.Parameters.AddWithValue("@id", requestId);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Заявка успешно обновлена.");
                this.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ошибка обновления заявки:\n" + ex.Message);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
